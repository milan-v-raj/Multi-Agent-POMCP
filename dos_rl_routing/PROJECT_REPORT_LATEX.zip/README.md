# LaTeX project report

`main.tex` is the complete editable report. The `figures/` directory contains the five main-report images used by it; keep the directory beside `main.tex`. `PROJECT_REPORT.pdf` is the compiled report.

## Overleaf

Upload `PROJECT_REPORT_LATEX.zip` as a new Overleaf project. The archive has `main.tex` at its root and contains all required figure files. Select `main.tex` as the main document and compile with pdfLaTeX. Set your own author/institution details in the title block if needed.

## Local compilation

With a standard TeX Live or MiKTeX installation, run from this folder:

```bash
pdflatex main.tex
pdflatex main.tex
```

The second run resolves the table of contents and citation links. The report cites its references directly; no separate BibTeX run is needed. The figures and numbers come from the completed network experiments in `../arq_fixed_suite/` and `../report_assets/`.
